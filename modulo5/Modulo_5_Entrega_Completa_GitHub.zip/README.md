# Módulo 5 — Dinámica de Sistemas

## Control de temperatura en un secador industrial de pepitas de uva

Este trabajo práctico de **Técnicas y Herramientas Modernas II** (Ingeniería Industrial, Facultad de Ingeniería de la Universidad Nacional de Cuyo, 2026) presenta un caso de estudio original de regulación térmica de una cámara de secado.

El objetivo es diseñar un modelo de dinámica de sistemas en **Vensim PLE** que permita comprender la realimentación negativa, el equilibrio térmico y el efecto de la saturación de potencia ante un cambio repentino de consigna. Se utiliza una representación concentrada de temperatura con dos flujos: calentamiento y enfriamiento.

Se comparan tres escenarios de simulación durante **12 horas**:

1. **Estabilidad:** temperatura objetivo constante de 60 °C, potencia máxima 20 kW.
2. **Perturbación STEP:** la consigna aumenta de 60 a 75 °C a partir de la hora 4, con 20 kW.
3. **Capacidad limitada:** se repite el salto de consigna, pero con una potencia máxima de 10 kW.

## Resultados y conclusión

Con las hipótesis adoptadas, el secador mantiene 60 °C en el caso estable. Al modificar la consigna, la temperatura simulada alcanza **74,95 °C** a las 12 h con 20 kW y **69,31 °C** con 10 kW. Se observa cómo la restricción energética reduce la velocidad de respuesta, sin producir oscilaciones en este modelo simplificado.

> **Nota:** los parámetros son supuestos didácticos, no datos de una instalación industrial ni temperaturas recomendadas para el secado de pepitas de uva.

## Archivos y accesos

- 🌐 [Ver la página web interactiva](index.html)
- 📄 [Ver el informe técnico en PDF](Informe_Modulo_5_Dinamica_de_Sistemas.pdf)
- 🧩 [Vensim — Escenario base](modelo_base.mdl)
- 🧩 [Vensim — Escenario STEP](modelo_escalon.mdl)
- 🧩 [Vensim — Potencia restringida](modelo_potencia_limitada.mdl)
- 📊 [Resultados numéricos CSV](resultados_simulacion.csv)
- 📈 [Gráfico de temperatura](grafico_temperatura.png)
- 📉 [Gráfico de potencia](grafico_potencia.png)

## Cómo usar el modelo de Vensim

Descargar cualquiera de los archivos `.mdl`, abrirlo con Vensim PLE mediante **File → Open Model**, comprobar las ecuaciones (**Model → Check Model**, Ctrl+T) y las unidades (**Model → Units Check**, Ctrl+U), y ejecutar la simulación. El modelo está construido con `INTEG`, `STEP`, `MIN` y `MAX`. Se adjuntan tres archivos separados para facilitar la comparación.

**Verificación:** los resultados del informe se calcularon numéricamente con integración de Euler, usando el mismo paso temporal de los modelos (`TIME STEP = 0.05 Hour`). No se realizó una ejecución dentro de Vensim PLE en este entorno, por lo que debe verificarse su apertura y ejecución antes de la entrega.

## Publicación de la web con GitHub Pages

1. Crear un repositorio público para el módulo, por ejemplo `modulo_5`.
2. Subir **todos los archivos de esta carpeta** al directorio raíz, conservando sus nombres.
3. En el repositorio ir a **Settings → Pages** y elegir **Deploy from a branch → main → /(root)**.
4. GitHub Pages publicará `index.html` como página inicial. El enlace, una vez publicado, suele tener la forma `https://USUARIO.github.io/modulo_5/` (reemplazar USUARIO por tu cuenta de GitHub).

## Integrantes

Lucía Domínguez · Milagros Farina · Camila Sepúlveda · Julieta Valle  
Docente: Ricardo Raúl Palma  
Universidad Nacional de Cuyo · Facultad de Ingeniería · 2026

## Referencia técnica

- [Vensim: función STEP](https://www.vensim.com/documentation/20485.html)
- [Vensim: comprobación de sintaxis y unidades](https://www.vensim.com/documentation/20405.html)
- [Vensim: estructura de archivos .mdl](https://www.vensim.com/documentation/ref_sketch_format.html)
